8-Direction Top-Down Character Sprites
Last update: 5/4/2023

Includes:
8 Idles - 1 frame
8 Walk cycles - 8 frames

Info:
Recommended framerate: 8
Sprite height: 32-34 px.
Idle sprites are positioned in the first columns.
Walking sprites are positioned in columns 2-9 starting with 2 and ending with 9.

PERMISSIONS:
You may use this asset pack for personal and commercial needs. You may modify it to suit your needs, as long as you give appropriate credit.
You may NOT redistribute or resell this asset pack.

By: BossNelNel
https://bossnelnel.itch.io/
https://twitter.com/BossNelNel
https://www.instagram.com/bossnelnel/
https://www.youtube.com/channel/UCda-RnlmSBpncC7Qz6c73NQ
https://www.deviantart.com/darkphantomrick/gallery